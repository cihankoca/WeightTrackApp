package com.example.weighttrackapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditNumberActivity extends AppCompatActivity {

    private EditText editPhoneNumber;
    private DatabaseHelper dbHelper;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_number);

        // Debugging: Check if USER_ID is passed
        userId = getIntent().getIntExtra("USER_ID", -1);
        Log.d("EditNumberActivity", "Received USER_ID: " + userId);


        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);



        // Retrieve user ID from Intent
        userId = getIntent().getIntExtra("USER_ID", -1);
        if (userId == -1) {
            Toast.makeText(this, "Invalid user session. Please log in again.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize UI components
        editPhoneNumber = findViewById(R.id.edit_phone_number);
        Button saveButton = findViewById(R.id.save_button);
        ImageView backArrow = findViewById(R.id.back_arrow);

        // Fetch existing phone number from database
        String currentPhone = dbHelper.getUserPhoneNumber(userId);
        if (currentPhone != null) {
            editPhoneNumber.setText(currentPhone);
        }

        // Back arrow functionality
        backArrow.setOnClickListener(v -> finish());

        // Save button functionality
        saveButton.setOnClickListener(v -> {
            String newPhoneNumber = editPhoneNumber.getText().toString().trim();
            if (newPhoneNumber.isEmpty()) {
                Toast.makeText(EditNumberActivity.this, "Please enter a valid phone number.", Toast.LENGTH_SHORT).show();
            } else {
                boolean isUpdated = dbHelper.updateUserPhoneNumber(userId, newPhoneNumber);
                if (isUpdated) {
                    Toast.makeText(EditNumberActivity.this, "Phone number updated successfully!", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(EditNumberActivity.this, "Failed to update phone number. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
