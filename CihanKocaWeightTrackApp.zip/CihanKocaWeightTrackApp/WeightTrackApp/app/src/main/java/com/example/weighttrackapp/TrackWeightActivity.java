package com.example.weighttrackapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;


import java.util.ArrayList;

public class TrackWeightActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private WeightAdapter adapter;
    private DatabaseHelper dbHelper;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track_weight);

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Get the user ID from the intent
        userId = getIntent().getIntExtra("USER_ID", -1);
        if (userId == -1) {
            Toast.makeText(this, "Invalid user session. Please log in again.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        Log.d("TrackWeightActivity", "USER_ID received in Intent: " + userId);
        if (userId == -1) {
            Log.e("TrackWeightActivity", "Invalid USER_ID. Ending activity.");
            Toast.makeText(this, "Invalid user session. Please log in again.", Toast.LENGTH_SHORT).show();
            finish();
        }


        // Initialize RecyclerView
        recyclerView = findViewById(R.id.weight_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Load weight entries
        loadWeightEntries();

        // Set up Bottom Navigation
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Remove highlighting from Bottom Navigation
        //bottomNavigationView.setSelectedItemId(-1);


        // Handle Bottom Navigation
        //bottomNavigationView.setOnItemSelectedListener(item -> handleNavigation(item));
        // Set 'Track' as selected
        bottomNavigationView.setSelectedItemId(R.id.nav_track_weight);
        // Set navigation listener
        bottomNavigationView.setOnItemSelectedListener(this::handleNavigation);
    }

    /**
     * Load weight entries for the current user and display them in the RecyclerView.
     */
    private void loadWeightEntries() {
        ArrayList<DatabaseHelper.WeightEntry> weightEntries = dbHelper.getWeightEntriesAsList(userId);
        adapter = new WeightAdapter(weightEntries, dbHelper, userId, this);
        recyclerView.setAdapter(adapter);
    }

    /**
     * Handle navigation actions.
     */
    private boolean handleNavigation(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Navigate to DashBoardActivity
            Intent intent = new Intent(this, DashBoardActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            overridePendingTransition(0, 0);
            return true;
        } else if (id == R.id.nav_track_weight) {
            // Stay on this page
            return true;
        } else if (id == R.id.nav_account) {
            // Navigate to AccountActivity
            Intent intent = new Intent(this, AccountActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            overridePendingTransition(0, 0);
            return true;
        }
        return false;
    }
}
