package com.example.weighttrackapp;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
//import androidx.appcompat.widget.Toolbar;

public class CreateAccountActivity extends AppCompatActivity {

    // Declare the DatabaseHelper
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        // Initialize the DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Sign Up");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Reference UI elements
        EditText usernameEditText = findViewById(R.id.et_username);
        EditText phoneEditText = findViewById(R.id.et_phone_number);
        EditText passwordEditText = findViewById(R.id.et_password);
        EditText confirmPasswordEditText = findViewById(R.id.et_confirm_password);
        Button createAccountButton = findViewById(R.id.btn_create_account);

        createAccountButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String phone = phoneEditText.getText().toString().trim(); // Replace 'emailEditText' with 'phoneEditText
            String password = passwordEditText.getText().toString();
            String confirmPassword = confirmPasswordEditText.getText().toString();

            boolean isRegistered = dbHelper.registerUser(username, password, phone);

            if (username.isEmpty() || phone.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else if (!password.equals(confirmPassword)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            } else {
                // Insert user into the database
               // boolean isRegistered = dbHelper.registerUser(username, password, phone);
                if (isRegistered) {
                    Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show();
                    finish(); // Go back to the login screen
                } else {
                    Toast.makeText(this, "Error: Username may already exist", Toast.LENGTH_SHORT).show();
                }

    }
        });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Go back to the previous screen
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
