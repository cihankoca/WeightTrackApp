package com.example.weighttrackapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class WeightInputActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_input);

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);


        // Get user ID from intent
        userId = getIntent().getIntExtra("USER_ID", -1);
        Log.d("WeightInputActivity", "USER_ID received: " + userId); // Added logging
        if (userId == -1) {
            Log.e("WeightInputActivity", "Invalid USER_ID. Ending activity."); // Added error logging
            Toast.makeText(this, "Error: User not logged in!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Check if setup is already completed
        if (dbHelper.isSetupCompleted(userId)) {
            Log.d("WeightInputActivity", "Setup already completed for USER_ID: " + userId); // Added logging
            Intent intent = new Intent(this, DashBoardActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            finish();
        }

        // Reference UI elements
        EditText weightEditText = findViewById(R.id.et_weight);
        EditText goalWeightEditText = findViewById(R.id.et_goal_weight);
        Button saveButton = findViewById(R.id.btn_save_weight);
        ImageView rightArrowButton = findViewById(R.id.right_arrow_button);
        TextView goalMessageTextView = findViewById(R.id.tv_goal_message);

        // Initialize right arrow button to be disabled
        rightArrowButton.setClickable(false);
        rightArrowButton.setAlpha(0.5f); // Visually appear disabled
        goalMessageTextView.setVisibility(View.GONE); // Initially hidden

        // Save button listener
        saveButton.setOnClickListener(v -> {
            String weightStr = weightEditText.getText().toString().trim();
            String goalWeightStr = goalWeightEditText.getText().toString().trim();

            if (weightStr.isEmpty() || goalWeightStr.isEmpty()) {
                Log.e("WeightInputActivity", "Weight or goal weight fields are empty."); // Added logging
                Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show();
                return;
            }

            float currentWeight;
            float goalWeightValue;
            try {
                currentWeight = Float.parseFloat(weightStr);
                goalWeightValue = Float.parseFloat(goalWeightStr);

                if (currentWeight <= 0 || goalWeightValue <= 0) {
                    Log.e("WeightInputActivity", "Invalid weight values entered."); // Added logging
                    Toast.makeText(this, "Weights must be greater than 0", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid weight values", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save current weight as a weight entry and goal weight in user settings
            boolean isCurrentWeightSaved = dbHelper.addWeightEntry(userId, new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date()), currentWeight);
            boolean isGoalWeightSaved = dbHelper.saveGoalWeight(userId, goalWeightValue);

            if (isCurrentWeightSaved && isGoalWeightSaved) {
                Toast.makeText(this, "Weights saved successfully!", Toast.LENGTH_SHORT).show();

                // Display the goal message
                String goalWeightMessage = "Your goal weight is: " + goalWeightStr + " lbs!";
                goalMessageTextView.setText(goalWeightMessage);
                goalMessageTextView.setVisibility(View.VISIBLE);

                // Enable the right arrow button for navigation
                rightArrowButton.setClickable(true);
                rightArrowButton.setAlpha(1.0f);

                // Handle navigation to Dashboard
                rightArrowButton.setOnClickListener(view -> {
                    Log.d("WeightInputActivity", "Navigating to DashBoardActivity with USER_ID: " + userId); // Added logging
                    Intent intent = new Intent(this, DashBoardActivity.class);
                    intent.putExtra("USER_ID", userId);
                    //intent.putExtra("currentWeight", currentWeight);
                    //intent.putExtra("goalWeight", goalWeightValue);
                    startActivity(intent);
                    finish();
                });
            } else {
                Log.e("WeightInputActivity", "Failed to save weights for USER_ID: " + userId); // Added error logging
                Toast.makeText(this, "Failed to save weights", Toast.LENGTH_SHORT).show();
            }
        });

        // BottomNavigationView setup
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> handleNavigation(item));
    }

    /**
     * Handle BottomNavigationView item clicks
     */
    private boolean handleNavigation(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Log.d("WeightInputActivity", "Navigating to DashBoardActivity with USER_ID: " + userId); // Added logging
            Intent intent = new Intent(this, DashBoardActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            return true;
        } else if (id == R.id.nav_track_weight) {
            Log.d("WeightInputActivity", "Navigating to TrackWeightActivity with USER_ID: " + userId); // Added logging
            Intent intent = new Intent(this, TrackWeightActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            return true;
        } else if (id == R.id.nav_account) {
            Log.d("WeightInputActivity", "Navigating to AccountActivity with USER_ID: " + userId); // Added logging
            Intent intent = new Intent(this, AccountActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            return true;
        } else {
            return false;
        }
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
