package com.example.weighttrackapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log; // Import for logging

public class LoginActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Initialize UI elements
        EditText usernameEditText = findViewById(R.id.et_username);
        EditText passwordEditText = findViewById(R.id.et_password);
        Button loginButton = findViewById(R.id.btn_login);
        TextView forgotPassword = findViewById(R.id.tv_forgot_password);
        TextView signUpText = findViewById(R.id.tv_sign_up);
        Button allowSmsButton = findViewById(R.id.btn_allow_sms);

        // Handle Login Button
        loginButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            // Log username input
            Log.d("LoginActivity", "Attempting login for username: " + username);

// Validate credentials
            int userId = dbHelper.validateUser(username, password);

            if (userId == -1) {
                // Login failed
                Log.e("LoginActivity", "Invalid login for username: " + username);
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            } else {
                // Login successful
                Log.d("LoginActivity", "Login successful. USER_ID: " + userId);
                Toast.makeText(this, "Welcome back!", Toast.LENGTH_SHORT).show();

                // Check if setup is complete for the user
                if (dbHelper.isSetupCompleted(userId)) {
                    // Redirect to Dashboard if setup is complete
                    Log.d("LoginActivity", "Setup complete for USER_ID: " + userId + ". Redirecting to Dashboard.");
                    Intent intent = new Intent(LoginActivity.this, DashBoardActivity.class);
                    intent.putExtra("USER_ID", userId);
                    startActivity(intent);
                } else {
                    // Redirect to WeightInputActivity if setup is not complete
                    Log.d("LoginActivity", "Setup incomplete for USER_ID: " + userId + ". Redirecting to WeightInputActivity.");
                    Intent intent = new Intent(LoginActivity.this, WeightInputActivity.class);
                    intent.putExtra("USER_ID", userId);
                    startActivity(intent);
                }
                finish(); // Close LoginActivity
            }
        });


        // Handle Forgot Password
        forgotPassword.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, ResetPasswordActivity.class);
            startActivity(intent);
        });

        // Handle Sign Up
        signUpText.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, CreateAccountActivity.class);
            startActivity(intent);
        });



// Handle Allow SMS
        allowSmsButton.setOnClickListener(v -> {
            // Pass the logged-in user's ID to SmsPermissionActivity
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();
            int userId = dbHelper.validateUser(username, password);

            if (userId != -1) {
                Log.d("LoginActivity", "Redirecting to SMS Permissions for USER_ID: " + userId);
                Intent intent = new Intent(LoginActivity.this, SmsPermissionActivity.class);
                intent.putExtra("USER_ID", userId); // Pass USER_ID
                startActivity(intent);
            } else {
                Toast.makeText(this, "Please log in first to set SMS permissions.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
