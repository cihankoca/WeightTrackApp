package com.example.weighttrackapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;
import android.util.Log;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.formatter.ValueFormatter;



import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class DashBoardActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);
        // Retrieve user ID from Intent
        userId = getIntent().getIntExtra("USER_ID", -1);
        Log.d("DashBoardActivity", "USER_ID received in Intent: " + userId); // Added logging
        if (userId == -1) {
            Log.e("DashBoardActivity", "Invalid USER_ID. Ending activity."); // Added error logging
            Toast.makeText(this, "Invalid user session. Please log in again.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }



        // UI References
        TextView currentDateTextView = findViewById(R.id.current_date);
        TextView currentWeightTextView = findViewById(R.id.current_weight);
        EditText editCurrentWeightEditText = findViewById(R.id.edit_current_weight);
        ProgressBar progressBar = findViewById(R.id.progress_bar);
        LineChart lineChart = findViewById(R.id.line_chart);
        Button addWeightEntryButton = findViewById(R.id.btn_add_weight);
        Button editWeightButton = findViewById(R.id.edit_weight_button);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Set current date
        String currentDate = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date());
        currentDateTextView.setText(currentDate);



        // Fetch current weight and goal weight from the database
        final float[] currentWeight = {0};
        float goalWeight = dbHelper.getGoalWeight(userId);
        Log.d("DashBoardActivity", "Goal weight retrieved: " + goalWeight); // Added logging

        Cursor userCursor = dbHelper.getUserWeightData(userId);
        if (userCursor != null && userCursor.moveToFirst()) {
            currentWeight[0] = userCursor.getFloat(userCursor.getColumnIndexOrThrow("weight"));
            Log.d("DashBoardActivity", "Current weight retrieved: " + currentWeight[0]); // Added logging
            userCursor.close();
        } else {
            Log.e("DashBoardActivity", "No weight data found for USER_ID: " + userId); // Added error logging
        }

        // Initialize UI with fetched data
        currentWeightTextView.setText(String.format(Locale.getDefault(), "%.1f lbs", currentWeight[0]));
        updateDashboard(currentWeight[0], goalWeight);

        // Configure Add Weight Entry button
        addWeightEntryButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashBoardActivity.this, AddWeightEntryActivity.class);
            intent.putExtra("USER_ID", userId);
            intent.putExtra("goalWeight", goalWeight);
            Log.d("DashBoardActivity", "Navigating to AddWeightEntryActivity with USER_ID: " + userId); // Added logging
            startActivity(intent);
        });

        // Configure Edit button
        editWeightButton.setOnClickListener(v -> {
            if (editWeightButton.getText().toString().equals(getString(R.string.edit))) {
                // Switch to Edit mode
                currentWeightTextView.setVisibility(View.GONE);
                editCurrentWeightEditText.setVisibility(View.VISIBLE);
                editCurrentWeightEditText.setText(String.valueOf(currentWeight[0]));
                editWeightButton.setText(getString(R.string.save));
            } else {
                // Save the edited weight
                String newWeightStr = editCurrentWeightEditText.getText().toString().trim();
                if (!newWeightStr.isEmpty()) {
                    try {
                        float newWeight = Float.parseFloat(newWeightStr);
                        if (newWeight > 0) {
                            dbHelper.updateUserWeight(userId, newWeight); // Save to database
                            currentWeight[0] = newWeight;
                            updateDashboard(currentWeight[0], goalWeight);

                            // Switch back to View mode
                            editCurrentWeightEditText.setVisibility(View.GONE);
                            currentWeightTextView.setVisibility(View.VISIBLE);
                            editWeightButton.setText(getString(R.string.edit));
                        } else {
                            Toast.makeText(this, "Weight must be greater than 0", Toast.LENGTH_SHORT).show();
                        }
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Invalid weight entered", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Configure Line Chart
        setupChart(userId);

        // Configure Bottom Navigation
        // Highlight the Home icon in BottomNavigationView
        bottomNavigationView.setSelectedItemId(R.id.nav_home);
        // Set navigation listener
        bottomNavigationView.setOnItemSelectedListener(this::handleNavigation);
    }

    private void refreshDashboard() {
        Cursor userCursor = dbHelper.getUserWeightData(userId);
        if (userCursor != null && userCursor.moveToFirst()) {
            float currentWeight = userCursor.getFloat(userCursor.getColumnIndexOrThrow("weight"));
            userCursor.close();

            // Fetch goal weight
            float goalWeight = dbHelper.getGoalWeight(userId);

            // Update UI components
            updateDashboard(currentWeight, goalWeight);
        }
    }


    /**
     * Setup the LineChart with user's weight history.
     */
    private void setupChart(int userId) {
        LineChart lineChart = findViewById(R.id.line_chart);
        TextView chartPlaceholder = findViewById(R.id.chart_placeholder);

        Cursor weightEntriesCursor = dbHelper.getWeightEntries(userId);
        if (weightEntriesCursor != null) {
            ArrayList<Entry> entries = new ArrayList<>();
            ArrayList<String> dates = new ArrayList<>();
            int index = 0;

            while (weightEntriesCursor.moveToNext()) {
                float weight = weightEntriesCursor.getFloat(weightEntriesCursor.getColumnIndexOrThrow("weight"));
                String date = weightEntriesCursor.getString(weightEntriesCursor.getColumnIndexOrThrow("date"));
                entries.add(new Entry(index, weight));
                dates.add(date);
                index++;
            }
            weightEntriesCursor.close();

            if (!entries.isEmpty()) {
                // Populate chart
                LineDataSet lineDataSet = new LineDataSet(entries, "Weight History");
                lineDataSet.setLineWidth(2f);
                lineDataSet.setCircleRadius(4f);

                LineData data = new LineData(lineDataSet);
                lineChart.setData(data);

                XAxis xAxis = lineChart.getXAxis();
                xAxis.setValueFormatter(new ValueFormatter() {
                    @Override
                    public String getFormattedValue(float value) {
                        int index = Math.round(value); // Round to the nearest integer
                        if (index >= 0 && index < dates.size()) { // Ensure index is within bounds
                            return dates.get(index);
                        }
                        return ""; // Return an empty string if out of bounds
                    }
                });
                xAxis.setGranularity(1f);
                xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);

                lineChart.invalidate();
                chartPlaceholder.setVisibility(View.GONE); // Hide placeholder
                lineChart.setVisibility(View.VISIBLE);    // Show chart
            } else {
                chartPlaceholder.setVisibility(View.VISIBLE); // Show placeholder
                lineChart.setVisibility(View.GONE);           // Hide chart
            }
        }

    }



    /**
     * Update the dashboard UI components.
     */
    private void updateDashboard(float currentWeight, float goalWeight) {
        // Update progress bar
        ProgressBar progressBar = findViewById(R.id.progress_bar);
        int progress = calculateProgress(currentWeight, goalWeight);
        progressBar.setProgress(progress);

        // Update goal weight text
        TextView goalWeightTextView = findViewById(R.id.goal_weight_text);
        float remainingWeight = goalWeight - currentWeight;
        if (progress == 100) {
            goalWeightTextView.setText("Congratulations! You've reached your goal weight!");
        } else {
            goalWeightTextView.setText(String.format(Locale.getDefault(),
                    "Your goal is %.1f lbs. %.1f lbs to go for your goal!",
                    goalWeight, Math.abs(remainingWeight)));
        }

        // Update current weight text
        TextView currentWeightTextView = findViewById(R.id.current_weight);
        currentWeightTextView.setText(String.format(Locale.getDefault(), "%.1f lbs", currentWeight));
    }

    /**
     * Calculate progress percentage.
     */
    private int calculateProgress(float currentWeight, float goalWeight) {
        if (currentWeight > goalWeight) {
            return Math.min((int) ((goalWeight / currentWeight) * 100), 100);
        } else if (currentWeight < goalWeight) {
            return Math.min((int) ((currentWeight / goalWeight) * 100), 100);
        }
        return 100;
    }

    /**
     * Handle navigation clicks.
     */
    private boolean handleNavigation(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Current activity; do nothing
            return false; // Don't return true here
        } else if (id == R.id.nav_track_weight) {
            // Navigate to TrackWeightActivity (Track screen)
            Intent intent = new Intent(this, TrackWeightActivity.class);
            Log.d("DashBoardActivity", "Navigating to TrackWeightActivity with USER_ID: " + userId); // Added logging
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            overridePendingTransition(0, 0); // Disable transition animation
            return true;
        } else if (id == R.id.nav_account) {
            // Navigate to AccountActivity
            Intent intent = new Intent(this, AccountActivity.class);
            Log.d("DashBoardActivity", "Navigating to AccountActivity with USER_ID: " + userId); // Added logging
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            overridePendingTransition(0, 0); // Disable transition animation
            return true;
        } else {
            return false;
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        refreshDashboard(); // Refresh weight and progress
        setupChart(userId); // Reload the weight chart
    }

}
