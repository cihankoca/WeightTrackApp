package com.example.weighttrackapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weightTracker.db";
    private static final int DATABASE_VERSION = 3;

    // Users Table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_PHONE = "phone";

    // Weights Table
    private static final String TABLE_WEIGHTS = "weights";
    private static final String COLUMN_WEIGHT_ID = "id";
    private static final String COLUMN_USER_ID_FK = "user_id"; // Foreign key to users.id
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_WEIGHT = "weight";

    // User Settings Table (to save goal weight)
    private static final String TABLE_USER_SETTINGS = "user_settings";
    private static final String COLUMN_GOAL_WEIGHT = "goal_weight";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users Table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " ("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USERNAME + " TEXT UNIQUE, "
                + COLUMN_PASSWORD + " TEXT, "
                + COLUMN_PHONE + " TEXT UNIQUE)";
        db.execSQL(createUsersTable);

        // Create Weights Table
        String createWeightsTable = "CREATE TABLE " + TABLE_WEIGHTS + " ("
                + COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USER_ID_FK + " INTEGER, "
                + COLUMN_DATE + " TEXT, "
                + COLUMN_WEIGHT + " REAL, "
                + "FOREIGN KEY (" + COLUMN_USER_ID_FK + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + "))";
        db.execSQL(createWeightsTable);

        // Create User Settings Table
        String createUserSettingsTable = "CREATE TABLE " + TABLE_USER_SETTINGS + " ("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY, "
                + COLUMN_GOAL_WEIGHT + " REAL, "
                + "FOREIGN KEY (" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + "))";
        db.execSQL(createUserSettingsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER_SETTINGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // Register a new user
    public boolean registerUser(String username, String password, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password); // Hash password if needed
        values.put(COLUMN_PHONE, phone);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Validate login
    public int validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null);

        // Add this log to indicate we're attempting to validate the user
        Log.d("DatabaseHelper", "Attempting to validate user: " + username);

        if (cursor != null && cursor.moveToFirst()) {
            // Log the successful retrieval of USER_ID
            int userId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_USER_ID));
            Log.d("DatabaseHelper", "Validation successful. USER_ID: " + userId);
            cursor.close();
            return userId;
        }

        // Log the failure if no valid user is found
        Log.e("DatabaseHelper", "Validation failed for user: " + username);
        return -1; // Login failed
    }

    //SMS Permission
    public String getPhoneNumber(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                "users", // Table name
                new String[]{"phone"}, // Column to fetch
                "id=?", // Where clause
                new String[]{String.valueOf(userId)}, // Where args
                null, null, null
        );

        if (cursor != null && cursor.moveToFirst()) {
            String phoneNumber = cursor.getString(cursor.getColumnIndexOrThrow("phone"));
            cursor.close();
            return phoneNumber;
        }
        return null;
    }

    public String getUserName(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("users", new String[]{"username"}, "id=?", new String[]{String.valueOf(userId)}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            String username = cursor.getString(cursor.getColumnIndexOrThrow("username"));
            cursor.close();
            return username;
        }
        return "User";
    }


    // Retrieve User ID by Phone Number
    public int getUserIdByPhone(String phone) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_PHONE + "=?",
                new String[]{phone},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            int userId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_USER_ID));
            cursor.close();
            return userId;
        }
        return -1; // No user found
    }

    // Update Phone Number
    public boolean updatePhoneNumber(int userId, String newPhone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PHONE, newPhone);

        int rows = db.update(TABLE_USERS, values, COLUMN_USER_ID + "=?", new String[]{String.valueOf(userId)});
        return rows > 0;
    }

    // Save goal weight for a user
    public boolean saveGoalWeight(int userId, float goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);

        int rows = db.update(TABLE_USER_SETTINGS, values, COLUMN_USER_ID + "=?", new String[]{String.valueOf(userId)});
        if (rows == 0) { // Insert if no entry exists
            values.put(COLUMN_USER_ID, userId);
            long result = db.insert(TABLE_USER_SETTINGS, null, values);
            return result != -1;
        }
        return true;
    }

    // Retrieve goal weight for a user
    public float getGoalWeight(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER_SETTINGS,
                new String[]{COLUMN_GOAL_WEIGHT},
                COLUMN_USER_ID + "=?",
                new String[]{String.valueOf(userId)},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            float goalWeight = cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_GOAL_WEIGHT));
            cursor.close();
            return goalWeight;
        }
        return 0;
    }

    // Add a weight entry for a user
    public boolean addWeightEntry(int userId, String date, float weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID_FK, userId);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);

        long result = db.insert(TABLE_WEIGHTS, null, values);
        return result != -1;
    }

    // Get the current weight for a user
    public Cursor getUserWeightData(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_WEIGHTS,
                null,
                COLUMN_USER_ID_FK + "=?",
                new String[]{String.valueOf(userId)},
                null, null,
                COLUMN_DATE + " DESC", // Fetch the latest weight
                "1"); // Limit to one entry
    }

    // Update user's current weight
    public boolean updateUserWeight(int userId, float weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, weight);

        int rows = db.update(TABLE_WEIGHTS, values, COLUMN_USER_ID_FK + "=?", new String[]{String.valueOf(userId)});
        if (rows == 0) { // Insert if no weight exists
            values.put(COLUMN_USER_ID_FK, userId);
            values.put(COLUMN_DATE, new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date()));
            long result = db.insert(TABLE_WEIGHTS, null, values);
            return result != -1;
        }
        return true;
    }

    // Get all weight entries for a user
    public Cursor getWeightEntries(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_WEIGHTS,
                null,
                COLUMN_USER_ID_FK + "=?",
                new String[]{String.valueOf(userId)},
                null, null,
                COLUMN_DATE + " ASC");
    }

    // Delete a weight entry by ID
    public int deleteWeightEntry(int weightId) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_WEIGHTS, COLUMN_WEIGHT_ID + "=?", new String[]{String.valueOf(weightId)});
    }

    // Update a weight entry by ID
    public int updateWeightEntry(int weightId, String date, float weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);

        return db.update(TABLE_WEIGHTS, values, COLUMN_WEIGHT_ID + "=?", new String[]{String.valueOf(weightId)});
    }

    public boolean isSetupCompleted(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER_SETTINGS,
                new String[]{COLUMN_GOAL_WEIGHT},
                COLUMN_USER_ID + "=?",
                new String[]{String.valueOf(userId)},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            float goalWeight = cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_GOAL_WEIGHT));
            cursor.close();
            return goalWeight > 0; // If a valid goal weight exists
        }
        return false; // Setup not complete
    }

    public ArrayList<WeightEntry> getWeightEntriesAsList(int userId) {
        ArrayList<WeightEntry> weightEntries = new ArrayList<>();
        Cursor cursor = getWeightEntries(userId);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                float weight = cursor.getFloat(cursor.getColumnIndexOrThrow("weight"));
                weightEntries.add(new WeightEntry(id, date, weight));
            }
            cursor.close();
        }
        return weightEntries;
    }

    public class WeightEntry {
        private int id;
        private String date;
        private float weight;

        public WeightEntry(int id, String date, float weight) {
            this.id = id;
            this.date = date;
            this.weight = weight;
        }

        public int getId() {
            return id;
        }

        public String getDate() {
            return date;
        }

        public float getWeight() {
            return weight;
        }

        public void setWeight(float weight) {
            this.weight = weight; // Setter to update weight
        }
    }



    // Fetch user details
    public Cursor getUserDetails(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_USERS,
                new String[]{COLUMN_USERNAME, COLUMN_PHONE},
                COLUMN_USER_ID + "=?",
                new String[]{String.valueOf(userId)},
                null, null, null);
    }

    public String getUserPhoneNumber(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_PHONE},
                COLUMN_USER_ID + "=?",
                new String[]{String.valueOf(userId)},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            String phone = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PHONE));
            cursor.close();
            return phone;
        }
        return null; // Phone not found
    }

    public boolean updateUserPhoneNumber(int userId, String newPhoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PHONE, newPhoneNumber);

        int rowsAffected = db.update(TABLE_USERS, values, COLUMN_USER_ID + "=?", new String[]{String.valueOf(userId)});
        return rowsAffected > 0; // Return true if at least one row was updated
    }

    //Change Password on Account Page
    // Validate user by ID and current password
    public boolean validateUserById(int userId, String currentPassword) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_USER_ID + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{String.valueOf(userId), currentPassword},
                null, null, null);

        boolean isValid = cursor != null && cursor.moveToFirst();
        if (cursor != null) {
            cursor.close();
        }
        return isValid;
    }

    // Update user password
    public boolean updatePassword(int userId, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PASSWORD, newPassword);

        int rowsUpdated = db.update(TABLE_USERS, values, COLUMN_USER_ID + "=?", new String[]{String.valueOf(userId)});
        return rowsUpdated > 0;
    }


    // Delete a user account and all related data
    public int deleteUserAccount(int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            // Begin a transaction to ensure data consistency
            db.beginTransaction();

            // Delete user's weight entries
            db.delete(TABLE_WEIGHTS, COLUMN_USER_ID_FK + "=?", new String[]{String.valueOf(userId)});

            // Delete user's settings
            db.delete(TABLE_USER_SETTINGS, COLUMN_USER_ID + "=?", new String[]{String.valueOf(userId)});

            // Delete user from the users table
            int rowsDeleted = db.delete(TABLE_USERS, COLUMN_USER_ID + "=?", new String[]{String.valueOf(userId)});

            // Commit the transaction
            db.setTransactionSuccessful();
            return rowsDeleted; // Return the number of rows deleted from the users table
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error deleting user account: " + e.getMessage());
            return 0;
        } finally {
            // End the transaction
            db.endTransaction();
        }
    }


}

