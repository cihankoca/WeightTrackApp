package com.example.weighttrackapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ChangePasswordActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        // Retrieve user ID from Intent
        userId = getIntent().getIntExtra("USER_ID", -1);
        dbHelper = new DatabaseHelper(this);

        // Initialize UI components
        EditText currentPasswordEditText = findViewById(R.id.current_password);
        EditText newPasswordEditText = findViewById(R.id.new_password);
        EditText confirmPasswordEditText = findViewById(R.id.confirm_password);
        Button saveButton = findViewById(R.id.save_button);
        ImageView backArrow = findViewById(R.id.back_arrow);


        // Back arrow functionality
        backArrow.setOnClickListener(v -> finish());

        // Save Button Logic
        saveButton.setOnClickListener(v -> {
            String currentPassword = currentPasswordEditText.getText().toString().trim();
            String newPassword = newPasswordEditText.getText().toString().trim();
            String confirmPassword = confirmPasswordEditText.getText().toString().trim();

            // Validate input
            if (currentPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!newPassword.equals(confirmPassword)) {
                Toast.makeText(this, "New passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }

            // Verify current password
            if (dbHelper.validateUserById(userId, currentPassword)) {

                // Check if the new password is the same as the current password
                if (currentPassword.equals(newPassword)) {
                    Toast.makeText(this, "New password cannot be the same as the current password", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Update password
                boolean updated = dbHelper.updatePassword(userId, newPassword);
                if (updated) {
                    Toast.makeText(this, "Password updated successfully", Toast.LENGTH_SHORT).show();
                    finish(); // Go back to previous activity
                } else {
                    Toast.makeText(this, "Failed to update password. Please try again.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Current password is incorrect", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
