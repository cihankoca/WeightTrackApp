package com.example.weighttrackapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.database.Cursor;
import android.widget.TextView;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class AccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);


        // Retrieve user ID from Intent
        int userId = getIntent().getIntExtra("USER_ID", -1);
        DatabaseHelper dbHelper = new DatabaseHelper(this);

        // Fetch user details
        String username = "Unknown"; // Default username
        String phone = "";           // Default email

        if (userId != -1) {
            Cursor cursor = dbHelper.getUserDetails(userId);
            if (cursor != null && cursor.moveToFirst()) {
                username = cursor.getString(cursor.getColumnIndexOrThrow("username"));
                phone = cursor.getString(cursor.getColumnIndexOrThrow("phone"));
                cursor.close();
            }
        }

        // Update UI elements
        TextView nameTextView = findViewById(R.id.user_name);
        TextView usernameTextView = findViewById(R.id.user_username);

        nameTextView.setText(username); // Display user's name
        usernameTextView.setText("@" + username); // Display username below the name




        // Back button functionality
        findViewById(R.id.back_arrow).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Closes current activity and goes back to the previous one
            }
        });

        // Change Password functionality
        LinearLayout changePasswordSection = findViewById(R.id.change_password_section);
        changePasswordSection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the Change Password Activity
                Intent intent = new Intent(AccountActivity.this, ChangePasswordActivity.class);
                startActivity(intent);
            }
        });

        LinearLayout editNumberSection = findViewById(R.id.edit_number_section);
        editNumberSection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to Edit Number Activity
                int userId = getIntent().getIntExtra("USER_ID", -1); // Retrieve USER_ID from the intent
                if (userId != -1) { // Check if USER_ID is valid
                    Intent intent = new Intent(AccountActivity.this, EditNumberActivity.class);
                    intent.putExtra("USER_ID", userId); // Pass USER_ID to the EditNumberActivity
                    startActivity(intent);
                } else {
                    Toast.makeText(AccountActivity.this, "Invalid user session. Please log in again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Notifications functionality
        LinearLayout notificationsSection = findViewById(R.id.notifications_section);
        notificationsSection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the Notifications Activity
                Intent intent = new Intent(AccountActivity.this, NotificationsActivity.class);
                startActivity(intent);
            }
        });



        // Log Out button functionality
        LinearLayout logoutSection = findViewById(R.id.logout_section);
        logoutSection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Logic to log out the user
                Intent intent = new Intent(AccountActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });

        // Delete Account button functionality
        findViewById(R.id.delete_account_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show confirmation dialog
                new AlertDialog.Builder(AccountActivity.this)
                        .setTitle("Delete Account")
                        .setMessage("Are you sure you want to delete your account? This action cannot be undone.")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // Call deleteAccount method
                                boolean isDeleted = deleteAccount();
                                if (isDeleted) {
                                    Toast.makeText(AccountActivity.this, "Account deleted successfully.", Toast.LENGTH_SHORT).show();
                                    // Redirect to LoginActivity
                                    Intent intent = new Intent(AccountActivity.this, LoginActivity.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(AccountActivity.this, "Failed to delete account. Please try again.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                        .setNegativeButton("No", null)
                        .show();
            }
        });

        // Bottom Navigation Setup
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Set 'Account' as selected
        bottomNavigationView.setSelectedItemId(R.id.nav_account);

        bottomNavigationView.setOnItemSelectedListener(this::handleNavigation);
    }

    /**
     * Handle BottomNavigationView item clicks
     */
    private boolean handleNavigation(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Navigate to DashBoardActivity (Home screen)
            Intent intent = new Intent(this, DashBoardActivity.class);
            intent.putExtra("USER_ID", getIntent().getIntExtra("USER_ID", -1));
            startActivity(intent);
            overridePendingTransition(0, 0); // Disable transition animation
            return true;
        } else if (id == R.id.nav_track_weight) {
            // Navigate to TrackWeightActivity
            Intent intent = new Intent(this, TrackWeightActivity.class);
            intent.putExtra("USER_ID", getIntent().getIntExtra("USER_ID", -1));
            startActivity(intent);
            overridePendingTransition(0, 0); // Disable transition animation
            return true;

        } else if (id == R.id.nav_account) {
            // Current activity; do nothing
            return true;
        } else {
            return false;
        }
    }

    /**
     * Deletes the user account from the database.
     */
    private boolean deleteAccount() {
        try {
            DatabaseHelper dbHelper = new DatabaseHelper(this);
            int userId = getIntent().getIntExtra("USER_ID", -1);
            if (userId != -1) {
                // Call DatabaseHelper to delete the user
                return dbHelper.deleteUserAccount(userId) > 0; // Success if more than 0 rows deleted
            } else {
                Log.e("AccountActivity", "Invalid USER_ID");
                return false;
            }
        } catch (Exception e) {
            Log.e("AccountActivity", "Error deleting account: " + e.getMessage());
            return false;
        }
    }
}
