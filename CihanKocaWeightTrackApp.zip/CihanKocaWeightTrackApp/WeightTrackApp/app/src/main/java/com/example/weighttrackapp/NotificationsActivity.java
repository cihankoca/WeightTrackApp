package com.example.weighttrackapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;
import android.content.pm.PackageManager;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class NotificationsActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "SharedPrefs"; // Unified preferences
    private static final String PREFS_KEY_REMINDER = "isReminderEnabled";

    private Switch reminderSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission); // Reuse the same layout

        // Enable the default back arrow in the ActionBar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Initialize Switch
        reminderSwitch = findViewById(R.id.switch_reminder);

        // Load saved state
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean isReminderEnabled = sharedPreferences.getBoolean(PREFS_KEY_REMINDER, false);
        reminderSwitch.setChecked(isReminderEnabled);

        // Set listener for switch state change
        reminderSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean(PREFS_KEY_REMINDER, isChecked);
                editor.apply();

                if (isChecked) {
                    if (ContextCompat.checkSelfPermission(NotificationsActivity.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(NotificationsActivity.this, "Daily reminders enabled!", Toast.LENGTH_SHORT).show();
                    } else {
                        ActivityCompat.requestPermissions(NotificationsActivity.this, new String[]{Manifest.permission.SEND_SMS}, 1);
                    }
                } else {
                    Toast.makeText(NotificationsActivity.this, "Daily reminders disabled.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        // Handle the back button click
        finish(); // Close the current activity and return to the previous screen
        return true;
    }
}
