package com.example.weighttrackapp;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddWeightEntryActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 1;

    private DatabaseHelper dbHelper;
    private int userId;
    private EditText weightInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight_entry);

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Get the user ID from the intent
        userId = getIntent().getIntExtra("USER_ID", -1);
        if (userId == -1) {
            Toast.makeText(this, "Invalid user session. Please log in again.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Set Title
        TextView titleTextView = findViewById(R.id.title_text);
        titleTextView.setText(R.string.add_weight_title);

        // Show Current Date
        TextView dateTextView = findViewById(R.id.date_text);
        String currentDate = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date());
        dateTextView.setText(currentDate);

        // Weight Input Field
        weightInput = findViewById(R.id.weight_input);

        // Retrieve the goal weight from the database
        float goalWeight = dbHelper.getGoalWeight(userId);

        // Goal Section
        TextView goalWeightTextView = findViewById(R.id.goal_weight_text);
        goalWeightTextView.setText(String.format(Locale.getDefault(), "%.1f lbs", goalWeight));

        TextView goalDescriptionTextView = findViewById(R.id.goal_description);
        goalDescriptionTextView.setText(String.format(Locale.getDefault(), "Your goal is to reach %.1f lbs", goalWeight));

        // Save Button
        Button saveButton = findViewById(R.id.save_button);
        saveButton.setOnClickListener(v -> {
            String weightStr = weightInput.getText().toString().trim();
            if (!weightStr.isEmpty()) {
                try {
                    float weight = Float.parseFloat(weightStr);
                    if (weight > 0) {
                        // Save the weight to the database
                        String date = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date());
                        boolean isSaved = dbHelper.addWeightEntry(userId, date, weight);
                        if (isSaved) {
                            // Check if goal weight is achieved
                            checkAndNotifyGoalWeight(userId, weight);
                            Toast.makeText(this, "Weight saved: " + weight + " lbs", Toast.LENGTH_SHORT).show();

                            // Navigate back to the dashboard
                            Intent intent = new Intent(AddWeightEntryActivity.this, DashBoardActivity.class);
                            intent.putExtra("USER_ID", userId);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(this, "Failed to save weight entry.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "Weight must be greater than 0", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid weight entered", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            }
        });

        // Bottom Navigation Setup
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Remove highlights by not setting any selected item
        bottomNavigationView.setSelectedItemId(-1);

        // Handle navigation without highlighting any button
        bottomNavigationView.setOnItemSelectedListener(item -> handleNavigation(item));
    }

    /**
     * Check if the user's weight matches the goal weight and send an SMS notification.
     */
    private void checkAndNotifyGoalWeight(int userId, float newWeight) {
        float goalWeight = dbHelper.getGoalWeight(userId);

        SharedPreferences sharedPreferences = getSharedPreferences("SharedPrefs", MODE_PRIVATE);
        boolean isReminderEnabled = sharedPreferences.getBoolean("isReminderEnabled", false);

        if (!isReminderEnabled) {
            Log.d("NotificationCheck", "SMS notifications are disabled. No notification will be sent.");
            return; // Exit if notifications are disabled
        }

        // Check if the new weight equals the goal weight
        if (newWeight == goalWeight) {
            String phoneNumber = dbHelper.getPhoneNumber(userId);
            String userName = dbHelper.getUserName(userId);

            if (phoneNumber != null && !phoneNumber.isEmpty()) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    String message = "Hi " + userName + ", congratulations! You've reached your goal weight of " + goalWeight + " lbs! Keep up the great work!";
                    sendSms(phoneNumber, message); // Use the SMS sending function
                    Toast.makeText(this, "Goal weight achieved! Notification sent.", Toast.LENGTH_SHORT).show();
                } else {
                    // Request SMS permission if not granted
                    Log.e("SMSPermission", "SMS permission not granted");
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
                }
            } else {
                Log.e("PhoneNumber", "No phone number found for userId: " + userId);
                Toast.makeText(this, "Phone number not found. Cannot send notification.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Log.d("GoalCheck", "Weight " + newWeight + " does not match goal weight " + goalWeight);
        }
    }


    // Send SMS Function
    private void sendSms(String phoneNumber, String message) {
        android.telephony.SmsManager smsManager = android.telephony.SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }

    /**
     * Handle BottomNavigationView item clicks.
     */
    private boolean handleNavigation(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Navigate to DashBoardActivity (Home screen)
            Intent intent = new Intent(this, DashBoardActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            finish(); // Close current activity
            return true;
        } else if (id == R.id.nav_track_weight) {
            // Navigate to TrackWeightActivity
            Intent intent = new Intent(this, TrackWeightActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            finish(); // Close current activity
            return true;
        } else if (id == R.id.nav_account) {
            // Navigate to AccountActivity
            Intent intent = new Intent(this, AccountActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            finish(); // Close current activity
            return true;
        } else {
            return false;
        }
    }


}


