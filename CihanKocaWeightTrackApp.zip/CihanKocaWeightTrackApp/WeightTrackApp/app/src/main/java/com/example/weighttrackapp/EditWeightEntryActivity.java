package com.example.weighttrackapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditWeightEntryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int userId, weightId;
    private EditText weightInput, dateInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_weight_entry);

        dbHelper = new DatabaseHelper(this);

        // Retrieve intent data
        Intent intent = getIntent();
        userId = intent.getIntExtra("USER_ID", -1);
        weightId = intent.getIntExtra("WEIGHT_ID", -1);
        String date = intent.getStringExtra("DATE");
        float weight = intent.getFloatExtra("WEIGHT", 0);

        // Initialize UI components
        dateInput = findViewById(R.id.edit_date);
        weightInput = findViewById(R.id.edit_weight);
        dateInput.setText(date);
        weightInput.setText(String.valueOf(weight));

        // Save button logic
        Button saveButton = findViewById(R.id.save_button);
        saveButton.setOnClickListener(v -> saveChanges());
    }

    private void saveChanges() {
        String updatedDate = dateInput.getText().toString().trim();
        String updatedWeightStr = weightInput.getText().toString().trim();

        if (!updatedDate.isEmpty() && !updatedWeightStr.isEmpty()) {
            try {
                float updatedWeight = Float.parseFloat(updatedWeightStr);
                boolean updated = dbHelper.updateWeightEntry(weightId, updatedDate, updatedWeight) > 0;

                if (updated) {
                    Toast.makeText(this, "Entry updated successfully!", Toast.LENGTH_SHORT).show();
                    finish(); // Return to the previous screen
                } else {
                    Toast.makeText(this, "Failed to update entry.", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid weight entered.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
        }
    }
}
