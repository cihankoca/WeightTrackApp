package com.example.weighttrackapp;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {

    private final ArrayList<DatabaseHelper.WeightEntry> weightEntries;
    private final DatabaseHelper dbHelper;
    private final int userId;
    private final Context context;

    public WeightAdapter(ArrayList<DatabaseHelper.WeightEntry> weightEntries, DatabaseHelper dbHelper, int userId, Context context) {
        this.weightEntries = weightEntries;
        this.dbHelper = dbHelper;
        this.userId = userId;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.weight_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DatabaseHelper.WeightEntry entry = weightEntries.get(position);
        holder.dateTextView.setText(entry.getDate());
        holder.weightTextView.setText(String.format("%.1f lbs", entry.getWeight()));

        // Initially show the TextView and hide the EditText
        holder.weightTextView.setVisibility(View.VISIBLE);
        holder.weightEdit.setVisibility(View.GONE);

        // Handle delete button click
        holder.deleteButton.setOnClickListener(v -> {
            boolean deleted = dbHelper.deleteWeightEntry(entry.getId()) > 0;
            if (deleted) {
                weightEntries.remove(position);
                notifyItemRemoved(position);
                Toast.makeText(context, "Entry deleted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Failed to delete entry", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle edit button click
        holder.editButton.setOnClickListener(v -> {
            if (holder.weightEdit.getVisibility() == View.GONE) {
                // Show EditText and hide TextView
                holder.weightTextView.setVisibility(View.GONE);
                holder.weightEdit.setVisibility(View.VISIBLE);
                holder.weightEdit.setText(holder.weightTextView.getText().toString().replace(" lbs", ""));
            } else {
                // Save edited weight
                String newWeightStr = holder.weightEdit.getText().toString().trim();
                if (!newWeightStr.isEmpty()) {
                    try {
                        float newWeight = Float.parseFloat(newWeightStr);
                        boolean updated = dbHelper.updateWeightEntry(entry.getId(), entry.getDate(), newWeight) > 0;
                        if (updated) {
                            entry.setWeight(newWeight); // Update the local list
                            holder.weightTextView.setText(String.format("%.1f lbs", newWeight)); // Update the display
                            Toast.makeText(context, "Weight updated", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(context, "Failed to update weight", Toast.LENGTH_SHORT).show();
                        }
                    } catch (NumberFormatException e) {
                        Toast.makeText(context, "Invalid weight", Toast.LENGTH_SHORT).show();
                    }
                }

                // Hide EditText and show TextView
                holder.weightEdit.setVisibility(View.GONE);
                holder.weightTextView.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    public int getItemCount() {
        return weightEntries.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView, weightTextView;
        EditText weightEdit;
        ImageButton deleteButton, editButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.date_text);
            weightTextView = itemView.findViewById(R.id.weight_text); // Matches corrected XML
            weightEdit = itemView.findViewById(R.id.weight_edit); // Add EditText for editing weight
            deleteButton = itemView.findViewById(R.id.delete_button); // Matches corrected XML
            editButton = itemView.findViewById(R.id.edit_button); // Matches corrected XML
        }
    }
}
